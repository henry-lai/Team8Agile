﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AgileCmd
{
    interface IDisplay
    {
    }
}
